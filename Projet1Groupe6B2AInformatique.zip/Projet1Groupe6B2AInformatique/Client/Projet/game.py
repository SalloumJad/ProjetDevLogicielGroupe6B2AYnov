# -*- coding: utf-8 -*-

import socket
import os
import colorama
import player
# colorama est optionnel, et sers à colorer les print. Nous l'aurions utilisé si nous avions le temps.
from colorama import Fore
from colorama import Style

colorama.init()

""" Exemples d'utilisation de colorama.

BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE, RESET

print(Fore.BLUE + Style.BRIGHT + "This is the color of the sky" + Style.RESET_ALL)
print(Fore.GREEN + "This is the color of grass" + Style.RESET_ALL)
print(Fore.BLUE + Style.DIM + "This is a dimmer version of the sky" + Style.RESET_ALL)
print(Fore.YELLOW + "This is the color of the sun" + Style.RESET_ALL)
"""

# Création d'une commande qui permet de vider l'affichage de la console.
clear = lambda: os.system('cls')


hote = "192.168.10.1"
port = 64578

# Pise en place de la connexion
socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
socket.connect((hote, port))

# Création du joueur de la partie lors du lancement du jeu
p = player.Player()

class Game():
    
    def startGame(self): # La fonction du menu principal. Permet de retourner dans le menu du jeu sans relancer le système.
        self.mainMenu()
        
    
    def mainMenu(self):
        clear()
        print("Bienvenue au RPG!\nCeci est un RPG suivant des normes de fonctionnement hors de l'habituel.\nOn vous recommande donc de lire les instructions avant de commencer!")
        
        choice = -5
        
        while choice <= 0 or choice >= 5:
            choice = int(input("Entrez 1 pour Jouer, 2 pour les instructions, 3 pour charger une partie,  4 pour quitter :\n"))
        
        # Agit en fonction de la réponse du joueur dans la console.
        if (choice == 1):
            self.play()
        elif (choice == 2):
            self.instructions()
        elif (choice == 3):
            self.load()
        elif (choice == 4):
            self.quitGame()
            
    
    def instructions(self):
        clear()
        print("Le jeu consiste a se battre contre divers ennemis et de battre le boss final, le demon.\n")
        print("Pour cela, le joueur peut choisir une des trois classes: Guerrier, Mage et Voleur.\n")
        print("Celles-ci donnent des competances differantes mais gardent les memes stats de depart, incitant a une strategie changente.\n")
        print("\nChaque classe possede 4 competances.\n")
        print("Une competance utilisable chaque tour, une competance a effet puissant avec temps de recharge, un moyen de monter sa defence pendant un tour ainsi que sacrifier un tour afin de se soigner.\n")
        print("\nLe Guerrier possede une competance de base aux degats normaux, ainsi que d'un buff d'attaque durant 5 tours.\nC'est une classe equilibree, et puissante mais manquant de moyen facile de se soigner.\n\n")
        print("Le Mage possede une competance de base de nature moins puissante que celle du guerrier. Cependant son skill d'augmentation d'attaque lui permet de faire bien plus de degats que celui-si, bien que cela soit de temps plus court.\nC'est une classe infligant des degats puissants, en sacrifiant la defense et avec un soin remarquable.\n\n")
        print("Le Voleur possede une competance de base aux degats egaux a ceux du guerrier. Cependant il n'augmente pas son attaque comme celui-ci. Sa deuxieme competance est aussi une attaque, infligant moins de degats mais ajoutant une accumulation permatante de poison sur l'ennemi.\nCe poison aura effet chaque debut de tour - allie ou ennemi - et s'accumule a chaque utilisation.\nLe Voleur est donc tres efficace a infliger des degats sur longe periodes, mais possede moins de defense que le guerrier et moins de soin que le mage.\n\n")
        print("Chaque ennemi donne au joueur une somme fixe d'argent en fonction du type d'ennemi. Cet argent sera utilisable au magasin afin d'acheter des objets utilisables au combat ou se soigner.\nAttention! Le joueur n'ayant pas de moyen de fuir le combat, il faut etre attentif et ne pas se ruer sur des ennemis ayant l'air trop puissants.\nLe niveau des ennemis n'etant pas explique en avance, vous devrez vous servir de vos propres stats afin de mesurer la difficulte des ennemis a venir.\n\n")
        print("Ce jeu ne fonctionne pas sous le systeme de niveaux habituels. A la place, le joueur devra monter progressivement ses stats en utilisant ses competances :\nLes competances donneront une amelioration permanante des stats a chaque utilisation.\nExemple: les competances 1 et 2 montent l'attaque joueur tandis que la competance 3 monte la defense et la 4 monte le seuil de vie maximal du joueur.\n\n")
        print("Bonne chance et profitez bien !\n\n")
        
        choice = -5
        
        while choice <= 0 or choice >= 4:
            choice = int(input("Entrez 1 pour jouer, 2 pour revenir au menu et 3 pour quitter !\n"))
        
        # Le joueur à le choix après avoir lu les instructions. Donne plus de fléxibilité au joueur.
        if (choice == 1):
            self.play()
        elif (choice == 2):
            self.mainMenu()
        elif (choice == 3):
            self.quitGame()
        
        
        
    def play(self):
        clear()
        print("Vous pouvez choisir de vous battre contre une multitude d'ennemis differents, ordonnes par difficultee.\nConfrontez les comme bon vous semble. A votre aide se trouve une boutique afin de vous procurer d'objets et de vous soigner.\nBonne chance !\n\n")
        print("Combats disponibles :\n")
        print("1: Slime\n2: Goblin\n3: Orc\n4: Dragon\n5: Demon - BOSS\n\n")
        print("Autres choix : \n6: Stats\n7: Shop\n8: Quitter\n9: Sauvegarder")
        
        choice = -5
        
        while choice <= 0 or choice >= 10:
            choice = int(input())
        
        if (choice == 1):
            self.fight(choice)
        elif (choice == 2):
            self.fight(choice)
        elif (choice == 3):
            self.fight(choice)
        elif (choice == 4):
            self.fight(choice)
        elif (choice == 5):
            self.fight(choice)
        elif (choice == 6):
            self.mainMenu()
        elif (choice == 7):
            self.quitGame()
        elif (choice == 8):
            self.quitGame()
        elif (choice == 9):
            self.quitGame()

            
    def fight(self, choice):
        if (choice == 1):
            enemyHP = 10
            enemyName = "Slime"
        elif (choice == 2):
            enemyHP = 50
            enemyName = "Goblin"
        elif (choice == 3):
            enemyHP = 200
            enemyName = "Orc"
        elif (choice == 4):
            enemyHP = 5000
            enemyName = "Dragon"
        elif (choice == 5):
            enemyHP = 7000
            enemyName = "Demon"
        
        
        while p.hp > 0 or enemyHP > 0:
            # Pour les tests
            p.playerPoison = 1
            p.name = "Jad"
            val = enemyName + " " + str(p.hp) + " " + str(enemyHP) + " " + str(p.defense) + " " + p.name + " " + str(p.playerPoison)
            l = val.split(" ")

            socket.send(val.encode())
            
            
            
            socket.listen
            data = socket.recv(2048).decode()
            
            l = data.split()
            
            print ("Len:  " + str(len(l)))
            
            if (data != ""):
                for i in range(len(l)):
                    if i <= 22:
                        print(str(i) + ": " + l[i] + "\n")
                    if i == 23:
                        p.hp = int(l[23])
                    if i == 24:
                        enemyHP = int(l[24 - 1])

    
    def load(self):
        clear()
        
        
    
    def quitGame(self):
        val = "Quit"
        socket.send(val.encode())
        exit()