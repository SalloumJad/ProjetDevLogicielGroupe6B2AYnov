# -*- coding: utf-8 -*-

#import socket


class Slime():
    
    def __init__(self):
        self.hp = 10
        self.defense = 2
        self.attack = 3
        self.gold = 1
        self.name = "Slime"