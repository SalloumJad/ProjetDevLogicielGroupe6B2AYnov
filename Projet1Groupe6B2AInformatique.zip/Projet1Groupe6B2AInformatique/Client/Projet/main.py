# -*- coding: utf-8 -*-

import socket
import game

hote = "192.168.10.1"
port = 64578

socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
socket.connect((hote, port))

connectionState = True

print ("Connection on {}".format(port))
"""

if __name__ == "__main__":
    g = game.Game()
    g.startGame()
    

"""

if __name__ == "__main__":
    g = game.Game()
    g.startGame()
"""
val = "Dragon 50 5 Jad 1"
socket.send(val.encode())

socket.listen
data = socket.recv(2048).decode()
if (data != ""):
    print (data)
"""

socket.close()