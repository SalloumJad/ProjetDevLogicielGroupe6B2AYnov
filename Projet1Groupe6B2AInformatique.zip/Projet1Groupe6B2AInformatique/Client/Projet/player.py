# -*- coding: utf-8 -*-

#import socket

class Player():
    
    def __init__(self):
        self.hp = 50
        self.maxHP = 50
        self.defense = 5
        self.attack = 5
        self.name = ""
        self.playerPoison = 0;