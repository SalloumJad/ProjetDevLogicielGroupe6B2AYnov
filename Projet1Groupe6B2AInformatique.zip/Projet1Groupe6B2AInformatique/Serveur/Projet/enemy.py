# -*- coding: utf-8 -*-

#import socket


class Enemy():
    
    
    def __init__(self, name):
        self.print = ""
        self.playerHP = 50
        
        if name == "Slime":
            self.hp = 10
            self.defense = 2
            self.attack = 3
            self.gold = 1
            self.name = "Slime"
            
            
        elif name == "Goblin":
            self.hp = 50
            self.defense = 10
            self.attack = 5
            self.gold = 2
            self.name = "Goblin"
            
        elif name == "Orc":
            self.hp = 200
            self.defense = 25
            self.attack = 15
            self.gold = 20
            self.name = "Orc"
            
        elif name == "Dragon":
            self.hp = 5000
            self.defense = 100
            self.attack = 50
            self.gold = 1000
            self.name = "Dragon"
            
        elif name == "Demon":
            self.hp = 7000
            self.defense = 200
            self.attack = 100
            self.gold = 100000
            self.name = "Demon"
            
    
    def enemyTurn(self, playerHP, enemyHP, playerDef, playerName, playerPoison):
        self.playerHP = playerHP
        self.hp = enemyHP
        self.print = ""
        
        if self.hp > 0:
            self.print += "Le " + self.name + " attaque ! "
            damage = self.attack - playerDef
            if damage <= 0:
                damage = 1
            
            self.print += "Le " + self.name + " inflige " + str(damage) + " degats a " + playerName + " ! "
            self.playerHP -= damage
            playerPoison = int(playerPoison)
            if playerPoison > 0 and self.playerHP > 0:
                self.print += "Le poison fait effet ! Le " + self.name + " prend " + str(playerPoison) + " degats !"
                self.hp -= playerPoison
            self.print += " " + str(self.playerHP) + " " + str(self.hp) 
            print (self.print)
        