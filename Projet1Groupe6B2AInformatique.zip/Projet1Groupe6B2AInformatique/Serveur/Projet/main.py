# -*- coding: utf-8 -*-

# Importation des librairies nécessaires au fonctionnement
import socket
import enemy

# Liste des joueurs entrant dans le serveur
playerList = []

#hote = "192.168.10.2"
#port = 64578

"""
e = enemy.Enemy("Slime")
print(str(e.playerHP) + "\n")
e.enemyTurn(50, 5, "Jad", 1)
print(str(e.playerHP) + "\n")
"""

# Variable qui change en fonction de l'état du jeu. True si il est en cours et False sinon
gameOn = True

# On lie le Socket avec les informations voulues (répliquées chez le(s) client(s))
socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
socket.bind(('0.0.0.0', 64578))

#clientsocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#clientsocket.connect((hote, port))

# Fonction du jeu principal.
while gameOn:
    # Continue à attendre les informations du client jusqu'à ce qu'il recoivent la fin de la partie.
    # Dans ce cas, ce serais la vie du joueur = 0, ou il décide de quitter le jeu et romp le signal.
    socket.listen(5)
    client, address = socket.accept()
    print ("{} connected".format(address))
    
    buf = ''.encode()
    buf += client.recv(2048)
    
    
    
    
    res = buf.decode()
    l = res.split(" ")
    
    if res != '' and l[0] == 'Quit':
        gameOn = False
    elif res != '':
        e = enemy.Enemy(l[0])
        e.enemyTurn(int(l[1]), int(l[2]), int(l[3]), l[4], int(l[5]))
        print(res)
        print("\n" + str(e.hp))
        
        client.send((e.print).encode())
    
        
print ("Fin du jeu!")
client.close()
socket.close()